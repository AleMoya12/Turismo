# Turismo

Puse los nombres y precios. Faltan las fotos, y copiar el texto. La seccion para turistas extranjeros queda igual como la pagina que mando al mail.
Falto poner una sola seccion q seria la de Cruceros (mismo precio), habra q hacer la ultima fila de 4. 
Lo q no esta, es porque dijo q no iba. 
Gracias totales :)
